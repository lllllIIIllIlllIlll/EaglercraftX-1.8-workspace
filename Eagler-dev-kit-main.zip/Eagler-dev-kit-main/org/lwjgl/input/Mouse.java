package org.lwjgl.input;

public class Mouse extends net.lax1dude.eaglercraft.v1_8.Mouse {

}
