package org.lwjgl;

public class LWJGLException extends Exception {
	private static final long serialVersionUID = 1L;
}
