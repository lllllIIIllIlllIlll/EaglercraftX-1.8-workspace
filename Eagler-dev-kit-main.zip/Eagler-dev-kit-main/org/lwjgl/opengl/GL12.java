package org.lwjgl.opengl;

public class GL12 extends GL11 {

}
