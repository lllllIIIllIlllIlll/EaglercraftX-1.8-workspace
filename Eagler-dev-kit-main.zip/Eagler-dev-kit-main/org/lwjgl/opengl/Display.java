package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;

public class Display extends net.lax1dude.eaglercraft.v1_8.Display {

}
